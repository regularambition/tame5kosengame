export const USER_NAME_RULES = {
  MIN_LENGTH: 1,
  MAX_LENGTH: 16,
  CHAR_CLASS: "[A-Za-z0-9ぁ-んァ-ヶー一-龯]",
} as const;
