export * from "./stringinput.js";
